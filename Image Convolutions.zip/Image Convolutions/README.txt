Open the .pde file and click "Run" - the arrow in the top corner, to run the project.

Controls:
Pressing the following keys will cause the following actions to occur:

0 - Displays the original image, no edits
1 - Displays the image in greyscale
2 - Displays the image after Sobel Operation (returns an image with color)
3 - Displays the image after Sobel Operation (returns an image in black and white)
4 - Displays the image with a Gaussian blur (5x5 kernel)
5 - Displays the image with a Sharpen convolution (3x3 kernel)
6 - Toggles the images: moves between 4 different images so that one can apply the effects in 0-6 on each of them. The four images are:
	1. A headshot of a cat
	2. An image of an engine
	3. A church at the base of a mountain
	4. A cabin beside a mountain lake

These are labelled in the order they will appear on-screen.