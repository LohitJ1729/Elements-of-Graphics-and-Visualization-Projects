Open HandsOnGameofLife.pde and click Run.

Press 'r' to randomly generate a grid for the game of life.

Press 'e' to erase the board.

Click on white tiles that you wish to turn black, and black tiles that you wish to turn back white. After clicking on the desired tiles, press 'p' to turn them black and play the game.

