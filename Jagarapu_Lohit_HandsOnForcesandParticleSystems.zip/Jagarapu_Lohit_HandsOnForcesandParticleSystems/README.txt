Open HandsOnForcesandParticleSystems.pde and click Run.

Press:

'd' to toggle directional light
's' to toggle spotlight
'a' to toggle ambient light
'p' to toggle point light