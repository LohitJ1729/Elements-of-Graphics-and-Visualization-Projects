Open HandsOnUsingMassesandSprings.pde and click Run.

Click anywhere on Canvas to move the first spring object there and see it bounce around.